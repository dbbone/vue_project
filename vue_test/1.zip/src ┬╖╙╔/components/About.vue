<template>
      <div>
          <h2>我是About的内容</h2>
      </div>
</template>

<script>
export default {
    name:'About'

}
</script>

<style>

</style>