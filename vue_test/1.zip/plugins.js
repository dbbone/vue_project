export default {
    install(Vue){
        Vue.mixin({
            
        })
    }
}