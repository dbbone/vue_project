<template>

  <el-descriptions class="margin-top" title="教师个人信息" :column="3" :size="size" border>
    <template slot="extra">
      <el-button type="primary" size="small">修改</el-button>
    </template>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-user"></i>
        用户名
      </template>
      {{username}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-work-num"></i>
        工号
      </template>
      {{worknum}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-college"></i>
        学院
      </template>
      {{college}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-department"></i>
        系部
      </template>
      {{department}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-profession"></i>
        专业
      </template>
      {{profession}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-title-post"></i>
        职称
      </template>
      {{titlepost}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-degree"></i>
        学位
      </template>
      {{degree}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-edu-bg"></i>
        学历
      </template>
      {{edu}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-telephone"></i>
        电话
      </template>
      {{telephone}}
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        <i class="el-icon-email"></i>
        邮箱
      </template>
      {{email}}
    </el-descriptions-item>
    
  </el-descriptions>
</template>

<script>
  export default {
    name:"jiaoshixinxi",
    data: {
        username: '23',
        worknum:  '123456',
        college: '123',
        department: '456',
        profession: '45',
        titlepost: '1',
        degree: '1',
        edu: '1',
        telephone: '12345678911',
        email: '123@163.com'
    }
  }
 
</script>