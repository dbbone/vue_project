<template>
   <div>
 <!-- <el-descriptions class="margin-top" title="我的团队1" :column="3"  border>
   
    <el-descriptions-item>
      <template slot="label">
        竞赛名称
      </template>
      1
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        团队负责人
      </template>
       1
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
       团队人数
      </template>
       1
    </el-descriptions-item>
 
    <el-descriptions-item>
      <template slot="label">
        指导老师1
      </template>
         1
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        学生团队
      </template>
      1
    </el-descriptions-item>
  </el-descriptions>


<el-descriptions class="margin-top" title="我的团队2" :column="3"  border>
   
    <el-descriptions-item>
      <template slot="label">
        竞赛名称
      </template>
      1
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        团队负责人
      </template>
       1
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
       团队人数
      </template>
       1
    </el-descriptions-item>
 
    <el-descriptions-item>
      <template slot="label">
        指导老师1
      </template>
         1
    </el-descriptions-item>
    <el-descriptions-item>
      <template slot="label">
        学生团队
      </template>
      1
    </el-descriptions-item>
  </el-descriptions> -->
 
   <el-descriptions class="margin-top" v-for="(p,index) in myteams" :key="index"  :title="`我的团队${index}`" :column="3"  border>


       <el-descriptions-item v-for=" (value1,key1,index) in p" :key="index">
      <template slot="label">
        {{key1}}
      </template>
       {{value1.toString()}}
    </el-descriptions-item>



   </el-descriptions>

   </div>
</template>

<script>
export default {
    name:'myteam',
    data(){
        return{
          
        }
    },
    computed:{
     myteams(){
     return this.$store.state.myteams
     }
    }
}
</script>

<style>

</style>