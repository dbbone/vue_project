<template>
  <div>

    
   <h1 style="text-align:center">20xx届已立项赛事信息</h1>

   
  <el-table
    :data="tableDataSearch"
    height="800"
    border
    style="width: 100%;margin-top:20px">
    <el-table-column
      prop="name"
      label="赛事"
      width="180">
     
    </el-table-column>
    <el-table-column
      prop="level"
      label="赛事等级"
      width="180">
    </el-table-column>
    <el-table-column
      prop="leader"
      label="赛事负责人">
    </el-table-column>
    
    
    <el-table-column>
    <el-button>查看详情</el-button>
    </el-table-column>
    

    <!-- <el-table-column>
      <template  slot-scope="scope"> 
       <span>{{scope.$index}}</span>
       <el-button>点击</el-button>
      </template>
      </el-table-column>  -->


    <el-table-column
      align="right">
      <template slot="header" slot-scope="scope"> <!--加了scope后才能输入    -->
        <el-input
          v-model="search"
          size="mini"
          placeholder="输入关键字搜索"/>
      </template>
      </el-table-column>
  </el-table>
  </div>
</template>

<script>
  export default {
      name:'saishi',
    data() {
      return {
        search:'',
        tableData: [{
         
          name: '蓝桥杯',
          level:'a',
          leader:'a',
          IA:'1'
        }, {
          name: 'ICPC',
           level:'a',
          leader:'b',
           IA:'1'
        }, {
          
          name: '软件外包',
          level:'a',
          leader:'c',
           IA:'1'
        }, {
          
          name: '大学生程序设计',
         level:'a',
          leader:'d',
           IA:'1'
        }, {
          
          name: '多媒体设计',
           level:'a',
          leader:'e', 
           IA:'1'
        }, {
        
          name: 'ccpc',
          level:'a',
          leader:'f',
           IA:'1'
        }, 
     ]
      }
    },
    methods:{
      consultall(){
        
      }
    },
    computed:{
      tableDataSearch() {    //筛选对象中的所有key value
      var input = this.search;  //username为input中的v-model参数
      if (input) {
        return this.tableData.filter((data) => {
          return Object.keys(data).some((key) => {
            return String(data[key]).toLowerCase().indexOf(input) > -1;
          });
        });
      }
      return this.tableData;
    },
  }
  }
</script>