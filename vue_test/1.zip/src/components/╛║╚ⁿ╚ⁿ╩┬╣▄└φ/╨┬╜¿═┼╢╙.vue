<template>
 <div>

   
   <div style="border: 1px solid;width:400px;margin-top:20px"> <!-- 包裹form表格的div  -->

   <h1 style="text-align:center">新建团队</h1>
   <el-form ref="form" :model="form" label-width="120px" >
     <el-form-item label="竞赛名称" class="it">
    <el-input v-model="form.竞赛项目"></el-input>
  </el-form-item>
  <el-form-item label="团队领导人" class="it">
    <el-input v-model="form.项目负责人"></el-input>
  </el-form-item>
   <el-form-item label="队伍名称" class="it">
    <el-input v-model="form.队伍名称"></el-input>
  </el-form-item>


  <el-form-item label="学生" class="it">
    <el-input  v-for="(p1,index) in form.参赛学生" :key="index"    v-model="form.参赛学生[index]"></el-input>
    <el-button @click="newstudent">新增学生</el-button>
  </el-form-item>
  <el-form-item label="老师" class="it">
    <el-input  v-for="(p,index) in form.指导老师" :key="index"    v-model="form.指导老师[index]"></el-input>
    <el-button @click="newteacher">新增老师</el-button>
  </el-form-item>

  
   <el-form-item> <el-button @click="submitnew">点击添加</el-button></el-form-item>
   </el-form>

     
   </div>    <!--包裹表格至此 -->



   <div style="margin-top:40px">          <!--学生资料表格 -->
    <h1>学生数据信息</h1>
   <el-table
    :data="DataSearch"
    height="400"
    border
    style="width: 100%">
    <el-table-column
      prop="login"
      label="姓名"
      width="180">
    </el-table-column>
    <el-table-column
      prop="html_url"
      label="来源"
      width="180">
    </el-table-column>
    <el-table-column
      align="right">
      <template slot="header" slot-scope="scope"> <!--加了scope后才能输入    -->
        <el-input
          v-model="search"
          size="mini"
          placeholder="输入关键字搜索"/>
          <el-button @click="getdata">获取数据</el-button>
      </template>
      </el-table-column>
  </el-table>
  
  <el-input v-model="searc" placeholder="输入要查询的id" style="width:200px"></el-input>
  <el-button @click="Test">
    点击请求数据2
  </el-button>
   </div>

 </div>
</template>

<script>
import axios from 'axios'
export default {
    name:'newteam',
    data(){
        return {
            users:[],
            
            form:{
              竞赛项目:'',
              项目负责人:'',
              指导老师:[],
              参赛学生:[],
              队伍名称:''
            },

            search:'',
            searc:'',
        }
    },

    computed:{
      tableDataSearch() {    //筛选对象中的所有key value
      var input = this.search;  //username为input中的v-model参数
      if (input) {
        return this.tableData.filter((data) => {
          return Object.keys(data).some((key) => {
            return String(data[key]).toLowerCase().indexOf(input) > -1;
          });
        });
      }
      return this.tableData;
    },
         DataSearch() {    //筛选对象中的所有key value
      var input = this.search;  //username为input中的v-model参数
      if (input) {
        return this.users.filter((user) => {
          return Object.keys(user).some((key) => {
            return String(user[key]).toLowerCase().indexOf(input) > -1;
          });
        });
      }
      return this.users;
    },
  },


    methods:{
      async getdata(){
         const{data:res}= await axios({
          method:'GET',
          url:'https://api.github.com/search/users?q=test',
      });
      console.log(res)   //此时的res就是 返回响应报文中的data
        let i= res.items.length;
      console.log(i)
        for(let j=0;j<i;j++){
            this.users.unshift({'login':res.items[j].login,'html_url':res.items[j].html_url,'avatar_url':res.items[j].avatar_url})  
            //为什么不直接 push({res.items[j]}) 因为其他数据是不需要的 只需要指定数据
            // this.users.push(res.items[j])
  
        }
      },
  //      showdata(res){
  //       let i= res.items.size;
  //       for(let j=0;j<i;j++){
  //           this.users.unshift({login:res.items[j].login,html_url:res.items[j].html_url,avatar_url:res.items[j].avatar_url})
                
  //       }
  // },
        

    async resstudent(){
         const{data:res}= await axios({
          method:'GET',
          url:"http://localhost/student/1",
          headers: {  'user-agent': 'Apifox/1.0.0 (https://www.apifox.cn)' ,'Accepet':'*/*','Accept-Encoding':'gzip,deflate'},
      });
      console.log(res.name)
 
    },

    Test(){
       axios.get('http://localhost:8080/test').then(
         response =>{'请求成功',console.log(response.data)},
         error=>{console.log('请求失败',error.message)}
       )
      
    },
  
//路由方法
  newteacher(){
    this.form.指导老师.push('')    //另一种方法 还没试 直接用students.length computed计算
  },

  newstudent(){
    this.form.参赛学生.push('')
  },
  
  submitnew(){
    this.$store.state.myteams.push(this.form)
    
     this.$alert('团队新建成功 请前往我的团队查看', '新建成功', {
          confirmButtonText: '确定',
          // callback: action => {
          //   this.$message({
          //     type: 'info',
          //     message: `action: ${ action }`
          //   });
          // }
        });
  }
  

    }
}
</script>

<style scoped>
    .it{
      width: 200px;
    }
</style>