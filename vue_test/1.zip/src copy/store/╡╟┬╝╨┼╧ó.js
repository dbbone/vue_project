
import vuex from 'vuex'
import Vue from 'vue'

const actions ={
    
}
const mutations={
 
     
}
const getters={
  
}
const state = {
 
}
Vue.use(vuex)
export default new vuex.Store({
    namespaced:true,
    actions:actions,
    mutations:mutations,
    state:state,
})