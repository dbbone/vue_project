<template>
    <div>
        这是主页面 展示当前老师所带团队 所参加的赛事相关 相关审核信息
    </div>
</template>

<script>
export default {
    name:'zhuye'
}
</script>

<style>

</style>