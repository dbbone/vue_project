<template>
   <div>
     这是所有指导老师或管理员信息
   </div>
</template>

<script>
export default {
    name:'teacher'
}
</script>

<style>

</style>