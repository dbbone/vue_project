module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset',
    //  原先 但是装入elemnetui 此时已过时["es2015", { "modules": false }],
    //[ "@babel/preset-env", { "modules": false }],
  ],
  // plugins: [
  //   [
  //     "component",
  //     {
  //       "libraryName": "element-ui",
  //       "styleLibraryName": "theme-chalk"
  //     }
  //   ]
  // ]
}
